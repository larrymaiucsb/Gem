/*
 * delay.h
 *
 *  Created on: Apr 7, 2022
 *      Author: Michael
 */

#ifndef SRC_DELAY_H_
#define SRC_DELAY_H_

#include "stm32l0xx_hal.h"
void delay(uint16_t time);

#endif /* SRC_DELAY_H_ */
